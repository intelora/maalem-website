"use strict";

module.exports = global.fetch;