module.exports = {
  babelrcRoots: ['.', 'packages/*'],
};
