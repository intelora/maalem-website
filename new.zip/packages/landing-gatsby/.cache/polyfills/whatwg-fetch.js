module.exports = {
  fetch: global.fetch,
}
