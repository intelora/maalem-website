module.exports = global.fetch
